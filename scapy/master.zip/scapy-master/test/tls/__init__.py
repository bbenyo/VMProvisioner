## This file is part of Scapy
## Copyright (C) 2016 Maxence Tury <maxence.tury@ssi.gouv.fr>
## This program is published under a GPLv2 license

"""
Examples and test PKI for the TLS module.
"""

